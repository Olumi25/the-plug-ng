# The Plug NG — first website prototype

A responsive static website prototype for a Nigerian opportunities board featuring Jobs, Paid gigs, and Grants.

## Open it
Open `index.html` in a browser. No build tools or paid hosting are required for local preview.

## Important before publishing
- The opportunity cards are explicitly **sample/demo listings**, not verified live opportunities.
- Replace the demo listings in `app.js` with real opportunities and official application URLs.
- Update `hello@theplugng.example` in `index.html` to an inbox you control.
- Newsletter form is a visual demo only; connect it to a real mailing-list service or remove it.
- Replace broad Google search links with the organiser's official application page for each listing.
- Add a privacy notice, terms, moderation/contact process, and a reporting path before collecting user data.

## Free publishing options
1. Create a GitHub account and a new public repository named `the-plug-ng`.
2. Upload `index.html`, `styles.css`, and `app.js` to the repository root.
3. Open repository Settings → Pages, select deploy from the main branch/root, and save.
4. GitHub Pages will provide a public URL after deployment. A custom domain is optional and usually costs extra.

## Update the opportunity board
Edit the `opportunities` array near the top of `app.js`. Each entry needs: `id`, `title`, `category` (`Jobs`, `Paid gigs`, or `Grants`), `type`, `summary`, `location`, `deadline`, `source`, and `tags`. Keep the CSV template as your tracking sheet. Verify every opportunity before marking it ready to publish.
